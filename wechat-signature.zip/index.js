const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 公众号配置 - 请替换成你的实际信息
const APP_ID = 'wx4854fa0dde42f7e8'
const APP_SECRET = '5070b8f30a56896016b98fc6aa6a5ceb'

/**
 * 获取 Access Token
 */
async function getAccessToken() {
  const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${APP_ID}&secret=${APP_SECRET}`
  const res = await cloud.fetch({
    url: url,
    method: 'GET'
  })
  return res.data.access_token
}

/**
 * 获取 Jsapi Ticket
 */
async function getJsApiTicket(accessToken) {
  const url = `https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=${accessToken}&type=jsapi`
  const res = await cloud.fetch({
    url: url,
    method: 'GET'
  })
  return res.data.ticket
}

/**
 * 生成随机字符串
 */
function createNonceStr(length = 16) {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let str = ''
  for (let i = 0; i < length; i++) {
    str += chars[Math.floor(Math.random() * chars.length)]
  }
  return str
}

/**
 * 云函数入口
 */
exports.main = async (event, context) => {
  const { url } = event

  if (!url) {
    return { error: '缺少url参数' }
  }

  try {
    // 获取 access_token
    const accessToken = await getAccessToken()

    // 获取 jsapi_ticket
    const jsapiTicket = await getJsApiTicket(accessToken)

    // 生成签名参数
    const nonceStr = createNonceStr()
    const timestamp = Math.floor(Date.now() / 1000)

    // 签名算法
    const string = `jsapi_ticket=${jsapiTicket}&noncestr=${nonceStr}&timestamp=${timestamp}&url=${url}`
    const signature = crypto.createHash('sha1').update(string).digest('hex')

    return {
      appId: APP_ID,
      timestamp,
      nonceStr,
      signature,
      success: true
    }
  } catch (error) {
    return {
      error: error.message || '获取签名失败',
      success: false
    }
  }
}
